# Shree Bhagwati Silver - Free Backend

A complete free backend solution for the Shree Bhagwati Silver website using Netlify Functions and Supabase.

## 🚀 Features

- **Free Backend**: Uses Netlify Functions (free tier)
- **Database**: Supabase PostgreSQL (free tier)
- **Admin Panel**: Complete management interface
- **Product Management**: Add, edit, delete products
- **Order Management**: Track and update orders
- **Customer Management**: Manage customer inquiries
- **Real-time Dashboard**: Live statistics and activity

## 📁 Project Structure

```
fresh-backend/
├── netlify/
│   └── functions/
│       ├── product.js    # Product CRUD operations
│       ├── order.js      # Order management
│       └── customer.js   # Customer management
├── admin-panel/
│   ├── index.html        # Admin panel interface
│   ├── styles.css        # Styling
│   └── script.js         # Admin panel functionality
├── netlify.toml          # Netlify configuration
├── package.json          # Dependencies
└── README.md            # This file
```

## 🛠️ Setup Instructions

### 1. Supabase Setup
1. Create account at [supabase.com](https://supabase.com)
2. Create new project
3. Run the SQL setup script in Supabase SQL Editor
4. Copy Project URL and anon key

### 2. Deploy to Netlify
1. Upload this folder to GitHub
2. Connect GitHub repo to Netlify
3. Set environment variables:
   - `SUPABASE_URL`: Your Supabase project URL
   - `SUPABASE_ANON_KEY`: Your Supabase anon key

### 3. Access Admin Panel
- Visit: `https://yoursite.netlify.app/admin-panel/`
- Configure Supabase settings in the Settings tab

## 💰 Free Tier Limits

- **Netlify Functions**: 100k requests/month
- **Supabase**: 500MB storage, 50k monthly active users
- **Perfect for small to medium businesses**

## 🔧 API Endpoints

- `/.netlify/functions/product` - Product management
- `/.netlify/functions/order` - Order management  
- `/.netlify/functions/customer` - Customer management

## 📊 Admin Panel Features

- **Dashboard**: Live statistics and recent activity
- **Products**: Add, edit, delete products with images
- **Orders**: Track order status and customer details
- **Customers**: Manage customer inquiries and contact info
- **Settings**: Configure Supabase connection

## 🎯 Ready to Deploy!

This backend is production-ready and completely free to use!
