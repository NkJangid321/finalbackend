const { createClient } = require('@supabase/supabase-js');

exports.handler = async function(event, context) {
  // Enable CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS'
  };

  // Handle preflight request
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  try {
    // Get environment variables
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseKey = process.env.SUPABASE_ANON_KEY;

    if (!supabaseUrl || !supabaseKey) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          error: 'Supabase credentials not configured',
          message: 'Please set SUPABASE_URL and SUPABASE_ANON_KEY environment variables'
        })
      };
    }

    const supabase = createClient(supabaseUrl, supabaseKey);

    // Handle different HTTP methods
    switch (event.httpMethod) {
      case 'GET':
        const { data: products, error: getError } = await supabase
          .from('products')
          .select('*')
          .order('created_at', { ascending: false });

        if (getError) throw getError;

        return {
          statusCode: 200,
          headers,
          body: JSON.stringify(products || [])
        };

      case 'POST':
        const productData = JSON.parse(event.body);
        const { data: newProduct, error: postError } = await supabase
          .from('products')
          .insert([productData])
          .select();

        if (postError) throw postError;

        return {
          statusCode: 201,
          headers,
          body: JSON.stringify(newProduct[0])
        };

      default:
        return {
          statusCode: 405,
          headers,
          body: JSON.stringify({ error: 'Method not allowed' })
        };
    }

  } catch (error) {
    console.error('Function error:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'Internal server error',
        message: error.message
      })
    };
  }
};
