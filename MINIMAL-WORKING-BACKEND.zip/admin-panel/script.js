// Admin Panel JavaScript
class AdminPanel {
    constructor() {
        this.currentTab = 'dashboard';
        this.supabaseUrl = '';
        this.supabaseKey = '';
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadSettings();
        this.loadDashboard();
    }

    setupEventListeners() {
        // Tab navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const tab = item.getAttribute('data-tab');
                this.switchTab(tab);
            });
        });

        // Add product button
        document.getElementById('addProductBtn').addEventListener('click', () => {
            this.showAddProductModal();
        });

        // Add product form
        document.getElementById('addProductForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.addProduct();
        });

        // Save settings
        document.getElementById('saveSettingsBtn').addEventListener('click', () => {
            this.saveSettings();
        });

        // Modal close
        document.querySelector('.close').addEventListener('click', () => {
            this.hideAddProductModal();
        });

        // Logout
        document.getElementById('logoutBtn').addEventListener('click', () => {
            this.logout();
        });
    }

    switchTab(tabName) {
        // Hide all tabs
        document.querySelectorAll('.tab-content').forEach(tab => {
            tab.classList.remove('active');
        });

        // Remove active class from all nav items
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });

        // Show selected tab
        document.getElementById(tabName).classList.add('active');

        // Add active class to selected nav item
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

        this.currentTab = tabName;

        // Load tab content
        switch (tabName) {
            case 'dashboard':
                this.loadDashboard();
                break;
            case 'products':
                this.loadProducts();
                break;
            case 'orders':
                this.loadOrders();
                break;
            case 'customers':
                this.loadCustomers();
                break;
        }
    }

    async loadDashboard() {
        try {
            const [products, orders, customers] = await Promise.all([
                this.fetchProducts(),
                this.fetchOrders(),
                this.fetchCustomers()
            ]);

            // Update stats
            document.getElementById('totalProducts').textContent = products.length;
            document.getElementById('totalOrders').textContent = orders.length;
            document.getElementById('totalCustomers').textContent = customers.length;

            // Calculate revenue
            const revenue = orders.reduce((total, order) => {
                return total + (order.total_amount || 0);
            }, 0);
            document.getElementById('totalRevenue').textContent = `₹${revenue.toFixed(2)}`;

            // Load recent activity
            this.loadRecentActivity(products, orders, customers);

        } catch (error) {
            console.error('Error loading dashboard:', error);
            this.showNotification('Error loading dashboard', 'error');
        }
    }

    loadRecentActivity(products, orders, customers) {
        const activityList = document.getElementById('recentActivity');
        const activities = [];

        // Add recent products
        products.slice(0, 3).forEach(product => {
            activities.push({
                type: 'product',
                text: `New product added: ${product.name}`,
                time: new Date(product.created_at).toLocaleDateString()
            });
        });

        // Add recent orders
        orders.slice(0, 3).forEach(order => {
            activities.push({
                type: 'order',
                text: `New order from ${order.customer_name}`,
                time: new Date(order.created_at).toLocaleDateString()
            });
        });

        // Add recent customers
        customers.slice(0, 3).forEach(customer => {
            activities.push({
                type: 'customer',
                text: `New customer: ${customer.name}`,
                time: new Date(customer.created_at).toLocaleDateString()
            });
        });

        // Sort by date and display
        activities.sort((a, b) => new Date(b.time) - new Date(a.time));
        
        activityList.innerHTML = activities.slice(0, 5).map(activity => `
            <div class="activity-item">
                <div style="display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-${this.getActivityIcon(activity.type)}" style="color: #667eea;"></i>
                    <div>
                        <p style="margin: 0; color: #2d3748;">${activity.text}</p>
                        <small style="color: #718096;">${activity.time}</small>
                    </div>
                </div>
            </div>
        `).join('');
    }

    getActivityIcon(type) {
        switch (type) {
            case 'product': return 'box';
            case 'order': return 'shopping-cart';
            case 'customer': return 'user';
            default: return 'info-circle';
        }
    }

    async loadProducts() {
        try {
            const products = await this.fetchProducts();
            this.displayProducts(products);
        } catch (error) {
            console.error('Error loading products:', error);
            this.showNotification('Error loading products', 'error');
        }
    }

    displayProducts(products) {
        const productsGrid = document.getElementById('productsGrid');
        
        if (products.length === 0) {
            productsGrid.innerHTML = '<p style="text-align: center; color: #718096; padding: 40px;">No products found. Add your first product!</p>';
            return;
        }

        productsGrid.innerHTML = products.map(product => `
            <div class="product-card">
                <div class="product-image">
                    ${product.image_url ? 
                        `<img src="${product.image_url}" alt="${product.name}" style="width: 100%; height: 100%; object-fit: cover;">` :
                        `<i class="fas fa-image" style="font-size: 40px;"></i>`
                    }
                </div>
                <div class="product-info">
                    <div class="product-name">${product.name}</div>
                    <div class="product-category">${product.category}</div>
                    <div class="product-price">₹${product.price}</div>
                    <div style="margin-bottom: 15px; color: #718096;">
                        Stock: ${product.stock_quantity} units
                    </div>
                    <div class="product-actions">
                        <button class="btn btn-secondary" onclick="adminPanel.editProduct(${product.id})">
                            <i class="fas fa-edit"></i> Edit
                        </button>
                        <button class="btn btn-danger" onclick="adminPanel.deleteProduct(${product.id})">
                            <i class="fas fa-trash"></i> Delete
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
    }

    async loadOrders() {
        try {
            const orders = await this.fetchOrders();
            this.displayOrders(orders);
        } catch (error) {
            console.error('Error loading orders:', error);
            this.showNotification('Error loading orders', 'error');
        }
    }

    displayOrders(orders) {
        const ordersList = document.getElementById('ordersList');
        
        if (orders.length === 0) {
            ordersList.innerHTML = '<p style="text-align: center; color: #718096; padding: 40px;">No orders found.</p>';
            return;
        }

        ordersList.innerHTML = orders.map(order => `
            <div class="order-item">
                <div class="order-info">
                    <h3>${order.customer_name}</h3>
                    <p>${order.customer_email} • ${order.customer_phone || 'No phone'}</p>
                    <p>Product ID: ${order.product_id} • Quantity: ${order.quantity}</p>
                    <p>Total: ₹${order.total_amount}</p>
                </div>
                <div>
                    <span class="order-status status-${order.status}">${order.status}</span>
                    <button class="btn btn-secondary" onclick="adminPanel.updateOrderStatus(${order.id}, '${order.status === 'pending' ? 'completed' : 'pending'}')">
                        ${order.status === 'pending' ? 'Mark Complete' : 'Mark Pending'}
                    </button>
                </div>
            </div>
        `).join('');
    }

    async loadCustomers() {
        try {
            const customers = await this.fetchCustomers();
            this.displayCustomers(customers);
        } catch (error) {
            console.error('Error loading customers:', error);
            this.showNotification('Error loading customers', 'error');
        }
    }

    displayCustomers(customers) {
        const customersList = document.getElementById('customersList');
        
        if (customers.length === 0) {
            customersList.innerHTML = '<p style="text-align: center; color: #718096; padding: 40px;">No customers found.</p>';
            return;
        }

        customersList.innerHTML = customers.map(customer => `
            <div class="customer-item">
                <div class="customer-name">${customer.name}</div>
                <div class="customer-email">${customer.email}</div>
                ${customer.phone ? `<div style="color: #718096; margin-bottom: 10px;">Phone: ${customer.phone}</div>` : ''}
                <div class="customer-message">${customer.message}</div>
            </div>
        `).join('');
    }

    showAddProductModal() {
        document.getElementById('addProductModal').style.display = 'block';
    }

    hideAddProductModal() {
        document.getElementById('addProductModal').style.display = 'none';
        document.getElementById('addProductForm').reset();
    }

    async addProduct() {
        try {
            const formData = new FormData(document.getElementById('addProductForm'));
            const productData = {
                name: formData.get('name'),
                description: formData.get('description'),
                category: formData.get('category'),
                price: parseFloat(formData.get('price')),
                stock_quantity: parseInt(formData.get('stock_quantity')),
                image_url: formData.get('image_url') || null
            };

            const response = await fetch('/.netlify/functions/product', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(productData)
            });

            if (response.ok) {
                this.showNotification('Product added successfully!', 'success');
                this.hideAddProductModal();
                this.loadProducts();
                this.loadDashboard();
            } else {
                throw new Error('Failed to add product');
            }
        } catch (error) {
            console.error('Error adding product:', error);
            this.showNotification('Error adding product', 'error');
        }
    }

    async editProduct(productId) {
        // Implementation for editing products
        this.showNotification('Edit functionality coming soon!', 'info');
    }

    async deleteProduct(productId) {
        if (confirm('Are you sure you want to delete this product?')) {
            try {
                const response = await fetch('/.netlify/functions/product', {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ id: productId })
                });

                if (response.ok) {
                    this.showNotification('Product deleted successfully!', 'success');
                    this.loadProducts();
                    this.loadDashboard();
                } else {
                    throw new Error('Failed to delete product');
                }
            } catch (error) {
                console.error('Error deleting product:', error);
                this.showNotification('Error deleting product', 'error');
            }
        }
    }

    async updateOrderStatus(orderId, newStatus) {
        try {
            const response = await fetch('/.netlify/functions/order', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ id: orderId, status: newStatus })
            });

            if (response.ok) {
                this.showNotification('Order status updated!', 'success');
                this.loadOrders();
                this.loadDashboard();
            } else {
                throw new Error('Failed to update order status');
            }
        } catch (error) {
            console.error('Error updating order status:', error);
            this.showNotification('Error updating order status', 'error');
        }
    }

    loadSettings() {
        const savedUrl = localStorage.getItem('supabaseUrl');
        const savedKey = localStorage.getItem('supabaseKey');
        
        if (savedUrl) document.getElementById('supabaseUrl').value = savedUrl;
        if (savedKey) document.getElementById('supabaseKey').value = savedKey;
    }

    saveSettings() {
        const url = document.getElementById('supabaseUrl').value;
        const key = document.getElementById('supabaseKey').value;

        if (!url || !key) {
            this.showNotification('Please fill in both URL and Key', 'error');
            return;
        }

        localStorage.setItem('supabaseUrl', url);
        localStorage.setItem('supabaseKey', key);
        
        this.supabaseUrl = url;
        this.supabaseKey = key;

        this.showNotification('Settings saved successfully!', 'success');
    }

    async fetchProducts() {
        const response = await fetch('/.netlify/functions/product');
        if (!response.ok) throw new Error('Failed to fetch products');
        const data = await response.json();
        return data.products || [];
    }

    async fetchOrders() {
        const response = await fetch('/.netlify/functions/order');
        if (!response.ok) throw new Error('Failed to fetch orders');
        const data = await response.json();
        return data.orders || [];
    }

    async fetchCustomers() {
        const response = await fetch('/.netlify/functions/customer');
        if (!response.ok) throw new Error('Failed to fetch customers');
        const data = await response.json();
        return data.customers || [];
    }

    showNotification(message, type = 'info') {
        // Simple notification system
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 8px;
            color: white;
            font-weight: 600;
            z-index: 10000;
            background: ${type === 'success' ? '#38a169' : type === 'error' ? '#e53e3e' : '#667eea'};
        `;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

    logout() {
        if (confirm('Are you sure you want to logout?')) {
            localStorage.removeItem('supabaseUrl');
            localStorage.removeItem('supabaseKey');
            window.location.reload();
        }
    }
}

// Initialize admin panel when page loads
document.addEventListener('DOMContentLoaded', () => {
    window.adminPanel = new AdminPanel();
});
